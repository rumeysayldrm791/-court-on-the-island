﻿/**
 * Adalı Mahkeme Maliyet Hesaplama Fonksiyonu
 * 5 Hâkimin tüm senaryolarını (Beraat, Çekimser, Suçlu) hesaplar ve en düşük maliyeti bulur.
 */
function hesaplaMaliyet() {
    // 1. Gerekli Değerleri HTML'den Okuma ve Doğrulama
    const juriSayisiInput = document.getElementById('juriSayisi');
    const juriRusvetInput = document.getElementById('jurorBribe') || document.getElementById('juriRusvet'); // İki farklı ID'ye hazırlıklı olalım
    const sonucMetniDiv = document.getElementById('sonucMetni');

    const juriSayisi = parseInt(juriSayisiInput.value);
    const juriRusvet = parseInt(juriRusvetInput.value);

    // Temel doğrulama
    if (isNaN(juriSayisi) || juriSayisi <= 0 || isNaN(juriRusvet) || juriRusvet < 0) {
        sonucMetniDiv.innerHTML = '<p style="color: red;">Lütfen geçerli (pozitif) Jüri Sayısı ve Jüri Rüşveti giriniz.</p>';
        return;
    }

    // 2. Hâkim Verilerini Toplama (index.html yapısına göre)
    const hakimGruplari = document.querySelectorAll('.hakim-grup');
    const hakimVerileri = Array.from(hakimGruplari).map(grup => {
        const id = parseInt(grup.getAttribute('data-hakim-id'));
        const beraatRusvet = parseInt(grup.querySelector('.rusvet-beraat').value);
        const cekimserRusvet = parseInt(grup.querySelector('.rusvet-cekimser').value);
        
        if (isNaN(beraatRusvet) || beraatRusvet < 0 || isNaN(cekimserRusvet) || cekimserRusvet < 0) {
             console.error(`Hata: Hâkim ${id} için rüşvet değerleri geçersiz.`);
             return null; 
        }
        
        return { id, beraatRusvet, cekimserRusvet, name: `Hâkim ${id}` };
    }).filter(h => h !== null);

    if (hakimVerileri.length === 0) {
        sonucMetniDiv.innerHTML = '<p style="color: red;">Hâkim verileri okunamadı veya geçersiz.</p>';
        return;
    }

    let enUcuzMaliyet = Infinity;
    let enIyiSenaryo = null;
    let tumSenaryolar = [];

    // --- 3. Maliyet Hesaplama Algoritması ---

    // Gerekli Jüri hesaplamaları:
    const gerekliJuri50 = Math.floor(juriSayisi / 2) + 1; // %50'den fazla
    const juriMaliyeti50 = gerekliJuri50 * juriRusvet;

    const gerekliJuri100 = juriSayisi; // %100
    const juriMaliyeti100 = gerekliJuri100 * juriRusvet;

    hakimVerileri.forEach(h => {
        
        // S1: Hâkim 'Beraat' verirse (Direkt Serbest)
        tumSenaryolar.push({
            hakimId: h.id,
            hakimAdi: h.name,
            karar: "Hâkim Beraat Verir (Direkt Serbest)",
            juriIhtiyaci: "0",
            toplamMaliyet: h.beraatRusvet,
            strateji: `Hâkimi kesin beraat kararı vermesi için ikna et (Maliyet: Hâkim Rüşveti)`,
        });

        // S2: Hâkim 'Çekimser' kalırsa (Jüri > %50 Beraat)
        tumSenaryolar.push({
            hakimId: h.id,
            hakimAdi: h.name,
            karar: "Hâkim Çekimser Kalır",
            juriIhtiyaci: `${gerekliJuri50}/${juriSayisi}`,
            toplamMaliyet: h.cekimserRusvet + juriMaliyeti50,
            strateji: `Hâkimi çekimser kalmaya ikna et (${h.cekimserRusvet} TL) ve ${gerekliJuri50} jüri üyesini ayarla (${juriMaliyeti50} TL).`,
        });

        // S3: Hâkim 'Suçlu' derse (Jüri %100 Beraat)
        // NOT: Hâkimin kararı "Suçlu" olsa bile, beraat etmenin yolu %100 jüri beraat oyu ise, sadece jüri maliyeti hesaplanır.
        tumSenaryolar.push({
            hakimId: h.id,
            hakimAdi: h.name,
            karar: "Hâkim Suçlu Der",
            juriIhtiyaci: `${gerekliJuri100}/${juriSayisi}`,
            // Hâkime rüşvet yok, sadece jüriyi ayarlama maliyeti.
            toplamMaliyet: juriMaliyeti100, 
            strateji: `Hâkimin kararına rağmen tüm jüriyi (${gerekliJuri100} üye) beraat için ayarla (Maliyet: Sadece Jüri Rüşveti)`,
        });
    });

    // --- 4. En Ucuz Senaryoyu Bulma ---
    tumSenaryolar.forEach(senaryo => {
        if (senaryo.toplamMaliyet < enUcuzMaliyet) {
            enUcuzMaliyet = senaryo.toplamMaliyet;
            enIyiSenaryo = senaryo;
        }
    });

    // --- 5. Sonucu Ekrana Yazma ---
    if (enIyiSenaryo) {
        sonucMetniDiv.innerHTML = `
            <p><strong>EN DÜŞÜK TOPLAM MALİYET: ${enUcuzMaliyet}</strong> Birim</p>
            <p>Bu maliyete ulaşmak için en uygun strateji:</p>
            <ul>
                <li><strong>Hâkim Seçimi:</strong> ${enIyiSenaryo.hakimAdi}</li>
                <li><strong>Hâkimin Karar Yolu:</strong> ${enIyiSenaryo.karar}</li>
                <li><strong>Jüri İhtiyacı:</strong> ${enIyiSenaryo.juriIhtiyaci} Jüri Üyesi Beraat Oyu</li>
                <li><strong>Strateji Detayı:</strong> ${enIyiSenaryo.strateji}</li>
            </ul>
        `;
    } else {
        sonucMetniDiv.innerHTML = '<p style="color: red;">Hesaplama yapılamadı. Giriş değerlerini kontrol ediniz.</p>';
    }
}
