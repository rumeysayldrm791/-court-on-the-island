﻿
Adalı Mahkeme Maliyet Analizi Proje Özeti

Bu uygulama, sunulan Case senaryosuna göre geliştirilmiş, beraat kararı almanın maliyet optimizasyonunu hedefleyen bir web simülatörüdür. Proje, hem algoritmik verimlilik hem de kullanıcı dostu arayüz tasarımı yetkinliklerini göstermektedir.

Proje Kapsamı ve Hedefi

Projenin temel amacı, Case'de belirtilen 5 farklı hâkim ve jüri oylama kuralları ışığında, en düşük toplam maliyetle beraat sonucunu garanti altına alacak stratejiyi hesaplamaktır.

Temel İşlevsellik

Uygulama, kullanıcıdan aldığı parametreler doğrultusunda, her bir hâkim için 3 farklı beraat yolu üzerinden toplam 15 olası stratejiyi analiz eder:

Doğrudan Beraat: Hâkimin doğrudan beraat kararı vermesi (Maliyet = Kesin Beraat Bedeli).

Çekimserlik: Hâkimin çekimser kalması ve jüri üyelerinin %50'den fazlasının beraat oyu vermesinin sağlanması.

Hâkimin Suçlu Kararı: Hâkimin suçlu kararına karşı, jüri üyelerinin %100'ünün beraat oyu vermesinin sağlanması.

Hesaplama sonucunda, Maliyet Analizi bölümünde en ucuz strateji ve bu stratejinin uygulandığı hâkim açıkça belirtilir.

Teknik Detaylar ve Başlatma

Proje, modern ve etkileşimli bir ön yüz (frontend) sunmak üzere saf web teknolojileri (HTML, CSS, JavaScript) kullanılarak geliştirilmiştir. Harici bir sunucuya ihtiyaç duymaz.

Başlatma Adımları

1.)Proje klasörünü yerel sisteminize indirin.

2.)Klasör içerisindeki index.html dosyasını web tarayıcınız (Chrome/Firefox/Edge) aracılığıyla açın.

Dosya Yapısı

index.html: Uygulamanın görsel yapısını ve tüm girdi/çıktı elemanlarını içerir.

css/styles.css: Kullanıcı deneyimini artıran sade, estetik ve mobil uyumlu tasarımı sağlar.

js/app.js: Tüm algoritmik hesaplamaları (özellikle hesapla En Düsük Maliyet fonksiyonu) yürüten ana JavaScript dosyasıdır.
